import sqlite3

# Połącz się z bazą danych
conn = sqlite3.connect('zmienne_do_q.db')
cursor = conn.cursor()

# Wykonaj zapytanie, aby pobrać wszystkie wiersze z tabeli q1
cursor.execute("SELECT * FROM q1")
rows = cursor.fetchall()

# Wyświetl wszystkie wiersze
for row in rows:
    print(row)

# Zamknij połączenie z bazą danych
conn.close()